# Linux Process Programs

These four independent C programs follow the code structure shown in the supplied screenshots. Only small corrections needed for reliable compilation/output and descriptor cleanup were applied.

## Compile individually

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -g multiple_children.c -o multiple_children
gcc -std=c11 -Wall -Wextra -Wpedantic -g orphan_process.c -o orphan_process
gcc -std=c11 -Wall -Wextra -Wpedantic -g zombie_process.c -o zombie_process
gcc -std=c11 -Wall -Wextra -Wpedantic -g two_pipe_communication.c -o two_pipe_communication
```

## Run individually

```bash
./multiple_children
./orphan_process
./zombie_process
./two_pipe_communication
```

## Makefile

Build one program at a time:

```bash
make multiple_children
make orphan_process
make zombie_process
make two_pipe_communication
```

Then run only the executable you selected. `make` by itself only displays help; it does not build or run all programs.

```bash
make clean
```

For the zombie demonstration, during the 10-second pause, use the child PID printed by the program:

```bash
ps -o pid,ppid,state,cmd -p <CHILD_PID>
```

A `Z` in the state column indicates a zombie process.

Requires Linux/WSL and GCC. These programs use POSIX APIs and are not native Windows CMD programs.
